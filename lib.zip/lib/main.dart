import 'package:flutter/material.dart';
import 'dart:ui';

void main() {
  runApp(WaterReminderApp());
}

class WaterReminderApp extends StatelessWidget {
  const WaterReminderApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Water Reminder',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.white,
      ),
      home: MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});
  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      HistoryScreen(),
      Placeholder(), // For Custom Input, handled as dialog
      ArticlesScreen(),
      SettingsScreen(),
    ];
    return Scaffold(
      body: Stack(
        children: [
          BlurryBackground(),
          _selectedIndex == 1
              ? HistoryScreen(showCustomInput: true)
              : screens[_selectedIndex],
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'History',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.article),
            label: 'Articles',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}

class BlurryBackground extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Gradient background
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.blue.withOpacity(0.5),
                Colors.cyan.withOpacity(0.3),
                Colors.white.withOpacity(0.7),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        // Blur effect
        BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
          child: Container(
            color: Colors.transparent,
          ),
        ),
      ],
    );
  }
}

class HistoryScreen extends StatefulWidget {
  final bool showCustomInput;
  HistoryScreen({this.showCustomInput = false});
  @override
  _HistoryScreenState createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  int _tabIndex = 2; // Month by default
  List<String> tabs = ['Day', 'Week', 'Month', 'Year'];
  List<Map<String, String>> summary = [
    {'amount': '60 L', 'label': 'March'},
    {'amount': '40 L', 'label': 'April'},
    {'amount': '60 L', 'label': 'May'},
  ];
  List<Map<String, String>> records = [
    {'amount': '550 ml', 'label': 'May'},
    {'amount': '150 ml', 'label': 'June'},
    {'amount': '150 ml', 'label': 'July'},
    {'amount': '150 ml', 'label': 'August'},
  ];

  void _showCustomInputDialog() {
    showDialog(
      context: context,
      builder: (context) => CustomInputDialog(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        ListView(
          padding: EdgeInsets.only(top: 60, left: 16, right: 16),
          children: [
            Text('History', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: tabs.asMap().entries.map((entry) {
                int idx = entry.key;
                String label = entry.value;
                return GestureDetector(
                  onTap: () => setState(() => _tabIndex = idx),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: _tabIndex == idx ? Colors.blue[100] : Colors.transparent,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(label, style: TextStyle(
                      color: _tabIndex == idx ? Colors.blue : Colors.black,
                      fontWeight: FontWeight.bold,
                    )),
                  ),
                );
              }).toList(),
            ),
            SizedBox(height: 24),
            Text(tabs[_tabIndex], style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 16),
            ...summary.map((item) => Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: ListTile(
                leading: Icon(Icons.local_drink, color: Colors.blue, size: 36),
                title: Text(item['amount']!),
                subtitle: Text(item['label']!),
              ),
            )),
            SizedBox(height: 24),
            ...records.map((item) => ListTile(
              leading: Icon(Icons.local_drink, color: Colors.blue),
              title: Text(item['amount']!),
              subtitle: Text(item['label']!),
            )),
          ],
        ),
        if (widget.showCustomInput)
          Align(
            alignment: Alignment.center,
            child: CustomInputDialog(),
          ),
      ],
    );
  }
}

class CustomInputDialog extends StatefulWidget {
  @override
  _CustomInputDialogState createState() => _CustomInputDialogState();
}

class _CustomInputDialogState extends State<CustomInputDialog> {
  int _selectedIcon = 0;
  int _amount = 0;
  final List<IconData> icons = [
    Icons.local_drink,
    Icons.local_bar,
    Icons.coffee,
    Icons.emoji_food_beverage,
    Icons.wine_bar,
    Icons.emoji_food_beverage_outlined,
  ];

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Custom', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 16),
            Wrap(
              spacing: 16,
              runSpacing: 16,
              children: List.generate(icons.length, (i) => GestureDetector(
                onTap: () => setState(() => _selectedIcon = i),
                child: CircleAvatar(
                  backgroundColor: _selectedIcon == i ? Colors.blue[100] : Colors.grey[200],
                  radius: 28,
                  child: Icon(icons[i], color: Colors.blue, size: 32),
                ),
              )),
            ),
            SizedBox(height: 24),
            Text('$_amount ml', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text('Cancel', style: TextStyle(color: Colors.blue)),
                ),
                ElevatedButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text('Ok'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class ArticlesScreen extends StatefulWidget {
  @override
  _ArticlesScreenState createState() => _ArticlesScreenState();
}

class _ArticlesScreenState extends State<ArticlesScreen> {
  int _tabIndex = 0;
  List<String> tabs = ['Drinking Water', 'Water Fasting'];
  List<Map<String, String>> articles = [
    {
      'title': 'Hydrate Your Way to Wellness',
      'subtitle': 'Why Regular Water Intake Matters',
      'date': '22/11/2024',
    },
    {
      'title': 'Stay Hydrated, Stay Healthy',
      'subtitle': 'Tips for Daily Water Intake',
      'date': '22/11/2024',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.only(top: 60, left: 16, right: 16),
      children: [
        Text('Articles', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        SizedBox(height: 16),
        Row(
          children: List.generate(tabs.length, (i) => Padding(
            padding: EdgeInsets.only(right: 16),
            child: GestureDetector(
              onTap: () => setState(() => _tabIndex = i),
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: _tabIndex == i ? Colors.blue[100] : Colors.transparent,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(tabs[i], style: TextStyle(
                  color: _tabIndex == i ? Colors.blue : Colors.black,
                  fontWeight: FontWeight.bold,
                )),
              ),
            ),
          )),
        ),
        SizedBox(height: 24),
        Text('Categories', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        SizedBox(height: 16),
        ...articles.map((article) => Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: ListTile(
            leading: Icon(Icons.image, color: Colors.blue, size: 48),
            title: Text(article['title']!),
            subtitle: Text(article['subtitle']!),
            trailing: Text(article['date']!, style: TextStyle(fontSize: 12)),
          ),
        )),
      ],
    );
  }
}

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // The blurry background is already provided by BlurryBackground in the main scaffold
        ListView(
          padding: EdgeInsets.only(top: 60, left: 16, right: 16),
          children: [
            Text('Settings', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            SizedBox(height: 24),
            ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                child: Container(
                  color: Colors.white.withOpacity(0.5),
                  padding: EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.settings, color: Colors.blue, size: 40),
                      SizedBox(height: 16),
                      Text(
                        'Settings Placeholder',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Your settings will appear here.',
                        style: TextStyle(fontSize: 16, color: Colors.black54),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}