import 'package:flutter/material.dart';
import 'theme.dart';

// Common widget for water container options
Widget buildWaterContainerOption(IconData icon, {bool isSelected = false, int? amount}) {
  return Container(
    width: 80,
    height: 80,
    decoration: BoxDecoration(
      color: isSelected ? AppTheme.primaryColor : Colors.white,
      borderRadius: BorderRadius.circular(20),
      boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.2),
          spreadRadius: 2,
          blurRadius: 5,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(
          icon,
          color: isSelected ? Colors.white : AppTheme.primaryColor,
          size: 30,
        ),
        if (amount != null)
          Padding(
            padding: const EdgeInsets.only(top: 5),
            child: Text(
              '$amount ml',
              style: TextStyle(
                color: isSelected ? Colors.white : Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ),
      ],
    ),
  );
}

// Common widget for water tracker card
Widget buildWaterTrackerCard(BuildContext context) {
  return Container(
    width: double.infinity,
    decoration: BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          AppTheme.primaryColor.withOpacity(0.8),
          AppTheme.primaryColor,
        ],
      ),
      borderRadius: BorderRadius.circular(20),
      boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.3),
          spreadRadius: 2,
          blurRadius: 5,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with logo and date
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.water_drop, color: Colors.white, size: 30),
                  SizedBox(width: 8),
                  Text(
                    'Hi Hydro-Tech',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ],
              ),
              Text(
                'Thursday, April 21',
                style: TextStyle(color: Colors.white70),
              ),
            ],
          ),
          SizedBox(height: 20),
          // Water progress section
          Center(
            child: Column(
              children: [
                Text(
                  '1.5L',
                  style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                Text(
                  'of 3.5L',
                  style: TextStyle(fontSize: 18, color: Colors.white70),
                ),
                SizedBox(height: 16),
                // Progress bar
                Container(
                  height: 10,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: FractionallySizedBox(
                    alignment: Alignment.centerLeft,
                    widthFactor: 0.43, // 1.5/3.5
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

// Common widget for custom water input card
Widget buildWaterInputCard(BuildContext context) {
  return Container(
    width: double.infinity,
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.2),
          spreadRadius: 2,
          blurRadius: 5,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with logo and date
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.water_drop, color: AppTheme.primaryColor, size: 30),
                  SizedBox(width: 8),
                  Text(
                    'Hi Hydro-Tech',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              Text(
                'Thursday, April 21',
                style: TextStyle(color: Colors.grey),
              ),
            ],
          ),
          SizedBox(height: 40),
          // Custom water input section
          Center(
            child: Column(
              children: [
                Text(
                  'Custom',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 24),
                // Container options
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    buildWaterContainerOption(Icons.local_drink, isSelected: true),
                    buildWaterContainerOption(Icons.wine_bar),
                    buildWaterContainerOption(Icons.coffee),
                  ],
                ),
                SizedBox(height: 24),
                // Second row of container options
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    buildWaterContainerOption(Icons.local_cafe),
                    buildWaterContainerOption(Icons.free_breakfast),
                    buildWaterContainerOption(Icons.water),
                  ],
                ),
                SizedBox(height: 32),
                // Custom amount input
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '250',
                        style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(width: 8),
                      Text(
                        'ml',
                        style: TextStyle(fontSize: 18, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 32),
                // Add button
                ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryColor,
                    padding: EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: Text(
                    'Add',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

// Common widget for history card
Widget buildHistoryCard(BuildContext context) {
  return Container(
    width: double.infinity,
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.2),
          spreadRadius: 2,
          blurRadius: 5,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with logo and date
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.water_drop, color: AppTheme.primaryColor, size: 30),
                  SizedBox(width: 8),
                  Text(
                    'Hi Hydro-Tech',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              Text(
                'Thursday, April 21',
                style: TextStyle(color: Colors.grey),
              ),
            ],
          ),
          SizedBox(height: 40),
          // History section
          Center(
            child: Column(
              children: [
                Text(
                  'History',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 24),
                // History items
                ListView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: 5,
                  itemBuilder: (context, index) {
                    return ListTile(
                      leading: Icon(Icons.water_drop, color: AppTheme.primaryColor),
                      title: Text('250ml Water'),
                      subtitle: Text('9:30 AM'),
                      trailing: Text('${index + 1}/5'),
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

// Common widget for settings card
Widget buildSettingsCard(BuildContext context) {
  return Container(
    width: double.infinity,
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.2),
          spreadRadius: 2,
          blurRadius: 5,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with logo and date
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.water_drop, color: AppTheme.primaryColor, size: 30),
                  SizedBox(width: 8),
                  Text(
                    'Hi Hydro-Tech',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              Text(
                'Thursday, April 21',
                style: TextStyle(color: Colors.grey),
              ),
            ],
          ),
          SizedBox(height: 40),
          // Settings section
          Center(
            child: Column(
              children: [
                Text(
                  'Settings',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 24),
                // Settings items
                ListTile(
                  leading: Icon(Icons.notifications, color: AppTheme.primaryColor),
                  title: Text('Reminders'),
                  trailing: Switch(
                    value: true,
                    onChanged: (value) {},
                    activeColor: AppTheme.primaryColor,
                  ),
                ),
                ListTile(
                  leading: Icon(Icons.water, color: AppTheme.primaryColor),
                  title: Text('Daily Goal'),
                  trailing: Text('3.5L'),
                ),
                ListTile(
                  leading: Icon(Icons.access_time, color: AppTheme.primaryColor),
                  title: Text('Reminder Frequency'),
                  trailing: Text('Every 2 hours'),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

// Common widget for reminder card
Widget buildReminderCard(BuildContext context) {
  return Container(
    width: double.infinity,
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.2),
          spreadRadius: 2,
          blurRadius: 5,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with logo and date
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.water_drop, color: AppTheme.primaryColor, size: 30),
                  SizedBox(width: 8),
                  Text(
                    'Hi Hydro-Tech',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              Text(
                'Thursday, April 21',
                style: TextStyle(color: Colors.grey),
              ),
            ],
          ),
          SizedBox(height: 40),
          // Reminder section
          Center(
            child: Column(
              children: [
                Text(
                  'Reminders',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 24),
                // Reminder items
                ListView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: 5,
                  itemBuilder: (context, index) {
                    return ListTile(
                      leading: Icon(Icons.access_time, color: AppTheme.primaryColor),
                      title: Text('Reminder ${index + 1}'),
                      subtitle: Text('${8 + index * 2}:00 ${index < 2 ? 'AM' : 'PM'}'),
                      trailing: Switch(
                        value: true,
                        onChanged: (value) {},
                        activeColor: AppTheme.primaryColor,
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}