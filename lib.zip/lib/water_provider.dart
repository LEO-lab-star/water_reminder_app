import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'notification_service.dart';

class WaterProvider with ChangeNotifier {
  int _waterIntake = 0;
  int _dailyGoal = 2000;
  final List<WaterRecord> _history = [];
  final SharedPreferences _prefs;

  WaterProvider(this._prefs) {
    _loadData();
    _checkDailyReset();
  }

  void _checkDailyReset() {
    final lastResetDate = _prefs.getString('lastResetDate') ?? '';
    final today = DateTime.now().toIso8601String().split('T')[0];
    
    if (lastResetDate != today) {
      resetDaily();
      _prefs.setString('lastResetDate', today);
    }
  }

  int get waterIntake => _waterIntake;
  int get dailyGoal => _dailyGoal;
  List<WaterRecord> get history => _history;

  void _loadData() {
    try {
      _waterIntake = _prefs.getInt('waterIntake') ?? 0;
      _dailyGoal = _prefs.getInt('dailyGoal') ?? 2000;
      
      // Load history from SharedPreferences
      final historyJson = _prefs.getStringList('history') ?? [];
      _history.clear();
      for (final json in historyJson) {
        final parts = json.split('|');
        if (parts.length == 2) {
          final amount = int.tryParse(parts[0]) ?? 0;
          final timestamp = DateTime.tryParse(parts[1]) ?? DateTime.now();
          _history.add(WaterRecord(amount, timestamp));
        }
      }
    } catch (e) {
      print('Error loading data: $e');
      // Initialize with defaults if loading fails
      _waterIntake = 0;
      _dailyGoal = 2000;
      _history.clear();
    } finally {
      notifyListeners();
    }
  }

  Future<void> addWater(int amount) async {
    try {
      _waterIntake += amount;
      await _prefs.setInt('waterIntake', _waterIntake);
      
      // Add to history
      final record = WaterRecord(amount, DateTime.now());
      _history.add(record);
      
      // Save history to SharedPreferences
      final historyJson = _history.map((record) => 
        '${record.amount}|${record.timestamp.toIso8601String()}'
      ).toList();
      await _prefs.setStringList('history', historyJson);
      
      // Show notification when water is added
      await NotificationService.showNotification(
        'Water Reminder', 
        'You added ${amount}ml of water. Total: ${_waterIntake}ml / ${_dailyGoal}ml'
      );
    } catch (e) {
      debugPrint('Error saving water intake: $e');
      // Add this to show error to user
      throw Exception('Failed to save water intake: $e');
    } finally {
      notifyListeners();
    }
  }

  Future<void> setDailyGoal(int goal) async {
    if (goal <= 0) {
      throw Exception('Daily goal must be greater than zero');
    }
    _dailyGoal = goal;
    await _prefs.setInt('dailyGoal', goal);
    notifyListeners();
  }

  Future<void> resetDaily() async {
    _waterIntake = 0;
    await _prefs.setInt('waterIntake', 0);
    notifyListeners();
  }
}

class WaterRecord {
  final int amount;
  final DateTime timestamp;

  WaterRecord(this.amount, this.timestamp);
}
